import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

/** 
 * @author Richard Lung
 * @version 1.0
 * */

public class GraphicsNewControl extends JPanel {
  
  // instance variables
  private GraphicsView viewPane;         
  private DrawingBoard db;                    // the simulation db
  private ShapeButtonListener buttonListener;  // listener object for buttons
  private ShapeMouseListener  mouseListener;   // listener object for mouse clicks
  
  
  /**
   * Construct a viewer/controller for the given db
   * @param w the model object this DrawingBoard object is controlling 
   *              and viewing
   */
  public GraphicsNewControl( DrawingBoard w ) {
    
    // capture model
    db = w;
    
    // default layout manager for JPanel is flow layout - we want border layout
    setLayout( new BorderLayout( ) );
    
    // create pane with ball display and place it in the center
    viewPane = new GraphicsView( db );
    viewPane.setPreferredSize( new Dimension( 1200,600 ) );
    add( viewPane, BorderLayout.CENTER );
    
    // register the view with the model
    db.addView( viewPane );
    
    // set up listener for mouse clicks on the view
    mouseListener = new ShapeMouseListener( db );
    viewPane.addMouseListener( mouseListener );
    mouseListener = new ShapeMouseListener(db);
    viewPane.addMouseMotionListener(mouseListener);
    
    // create panel with start/stop buttons and add it at the bottom
    JButton circleButton = new JButton( "Circle Button" );
    JButton triangleButton = new JButton( "Triangle Button" );
    JButton fillColor = new JButton( "Fill Color" );
    JButton colorButton = new JButton ("Change Color");
    JButton removeButton = new JButton ("Remove Shape");
    JButton eraseButton = new JButton ("Erase Board");
    JPanel buttons = new JPanel( );
    buttons.add( circleButton );
    buttons.add( triangleButton );
    buttons.add( fillColor );
    buttons.add( colorButton );
    buttons.add(removeButton);
    buttons.add(eraseButton);
    //set up the colors of the buttons
    circleButton.setBackground( Color.yellow );
    triangleButton.setBackground( Color.green );
    colorButton.setBackground(Color.blue);
    fillColor.setBackground( Color.red );
    removeButton.setBackground ( Color.orange );
    eraseButton.setBackground ( Color.pink);
    buttons.setBackground( Color.lightGray );
    this.add( buttons, BorderLayout.SOUTH );
    
    // set up listener for the buttons
    buttonListener = new ShapeButtonListener( db );
    circleButton.addActionListener( buttonListener );
    triangleButton.addActionListener( buttonListener );
    fillColor.addActionListener( buttonListener );
    colorButton.addActionListener( buttonListener );
    removeButton.addActionListener (buttonListener);
    eraseButton.addActionListener (buttonListener);
  }
  
}



//  Handle button clicks
  

class ShapeButtonListener implements ActionListener {
  // instance variables
  private DrawingBoard db; // the DrawingBoard model
  Color coloring;
  /**
   * Constructor for objects of class ShapeButton
   * @param db the model object of the simulation
   */
  public ShapeButtonListener( DrawingBoard db ) {
    this.db = db;
    
  }
  
  /**
   * Process button clicks by turning the simulation on and off
   * @param e the event created by the button click
   */
  public void actionPerformed( ActionEvent e ) {
    //if the circle button is clicked, then create status is true, which means we're creating the shapes
    if ( e.getActionCommand( ).equals( "Circle Button" ) ) {
      db.setcreateStatus(true);
      //set the status true for the Circle, false for the Triangle to distinguish them
      db.setStatus(true);
      //if the triangle button is clicked, then create status is true, which means we're creating the shapes
    } else if ( e.getActionCommand( ).equals( "Triangle Button" ) ) {
      db.setcreateStatus(true);
      
      //set the status true for the Circle, false for the Triangle to distinguish them
      db.setStatus(false);      
    } 
    
    //this is if the fill color button is clicked, the setCreate status will be false, which means they're filling the color
    //if the fill color is clicked, then if you selected the shape that is currently unselected, the color will be filled
    else if (e.getActionCommand().equals("Fill Color") ) {
      db.setcreateStatus(false);
      
      
    }
    //this is change color button, that will randomly change the color that will be filled to the shape
    else if ( e.getActionCommand().equals("Change Color")) {
      //calling the method from the drawing board that will set up the color randomly
      db.setColorSelected();
    
      
     db.notifyListener();
    }
    //this is remove shape to remove the curently selected shape and notifyListener
      else if ( e.getActionCommand().equals("Remove Shape")) {
      db.removeSelected();
     db.notifyListener();
      }
    
    
  //this is erasing the whole board so there's no more shape in the board.
  
  else if (e.getActionCommand().equals("Erase Board")) {
    if(db.getSize() >= 0) {
      
      for(int i = db.getSize(); i > 0; i--)
      {
         db.removeSelected();
         
      }
      
    }
     db.notifyListener();
  }
}
}

//  Handle mouse clicks

class ShapeMouseListener implements MouseListener, MouseMotionListener {
  // instance variables
  private DrawingBoard db; // the SimModel we are controlling

  /**
   * Constructor for objects of class ShapeMouseListener
   * @param db the model object containing the state of the system
   */
  public ShapeMouseListener( DrawingBoard db ) {
    super( );
    
    this.db = db;
    //set the initial action, to be creating cirle
      db.setcreateStatus(true);    
      db.setStatus(true);
  }

  /**
   * mouseDragged method to handle mousedragged
   * @param e the event created by the button dragged
   * */
  public void mouseDragged( MouseEvent e ) {
    //call the method shiftBy in the drawingboard to set a new location for the shape while mouse is dragged

   db.getSelected().shiftBy(e.getX()-db.getSelected().returnX(), e.getY()-db.getSelected().returnY());
    db.notifyListener();
 
  }

  
  
  /**
   * Process mouse click by adding a new ball to the simulation at the location
   * of the click with a random color, size, and velocity
   * @param e the mouse click event
   */
  public void mouseClicked( MouseEvent e ) {
    // if the create status true, than it means they are doing create shape else they're doing the Filled
    if(db.createStatus() == true ) {
      //status true will make the circle, while false will make the right triangle
      if( db.returnStatus() == true ) {
        db.addShape( new Circle( e.getX( ), e.getY( ),30, db.returnColor()  ));
      }
      
      else {
        db.addShape( new RightTriangle(e.getX(), e.getY(), 30,  db.returnColor() )); 
      }    }
    
    else {
      //this is the conditions when the create status is false, they're doing the Filled
      db.getSelected().setTesting();
      if ( db.checkCoor(e.getX(), e.getY()) == true) { 
        db.setCoordinateSelected(e.getX(), e.getY() ); 
        
      }
      
      else {}
      
    }
    
    db.notifyListener();
    
  }
  

  
  // dummy implementations for other events in mouselistener
  public void mouseMoved   ( MouseEvent e ) {  }
  public void mouseEntered ( MouseEvent e ) {}
  public void mouseExited  ( MouseEvent e ) {}
  public void mousePressed ( MouseEvent e ) {}
  public void mouseReleased( MouseEvent e ) {}
}
