import java.util.*;
import javax.swing.*;
import java.awt.*;

/** 
 * @author Richard Lung
 * @version 1.0
 * */

public class viewText extends JPanel implements viewInterface  {
 
//  private ArrayList<DrawingBoard> drawingboard;
  private DrawingBoard db;
   private JLabel disp, disp2;
   
   /**
    * creating a viewText. this is view1
    * This will be a text display to System.out. This will display the current number of shapes in the DrawingBoard, and the details of the selected shape (by calling toString()). If there is no currently selected shape, the text should say so.
    * @param db a DrawingBoard class
    * */
   
 public viewText ( DrawingBoard db ) {
    super( );
    
    //set up the disp for showing the Label
    disp = new JLabel( "" );
    this.add(disp);
    //set up the disp2 for showing the label
    disp2 = new JLabel ( "" );
    this.add(disp2);
    this.db = db;
    db.addListener( this ); 
  }   
    
 //override the notifyViewer method to show what is inside the drawing board.
 //this is also an extra credit Instead of the text view going to System.out, display the text in a JTextArea that is put in the JFrame. 
 public void notifyViewer() {
   if (db.getSize() == 0) {
      disp.setText("There is no shape in Drawing Board");
     disp2.setText("");
   }
    else
    {
    
      disp.setText(db.getSelected().toString());
        disp2.setText(". There are currently " + db.getSize() + " shape(s) in the Drawing Board");

    }
 
    }
     
   
 }
  
  


