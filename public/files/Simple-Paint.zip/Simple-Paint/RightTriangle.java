import java.awt.*;
/** 
 * @author Richard Lung
 * @version 1.0
 * */
//declare class RightTriangle extends the AbstractShape
public class RightTriangle extends AbstractShape{
  // this variable is to stored the value of x after it is added by height ( new value of x)
  int xrT; 
  // this variable is to stored the value of y after it is added by height ( new value of y)
  int yrT;
  int height;
  
  /**
   * declaring constructor to set up the x, y for the top left corner and height and  c of the RightTriangle
   * */
  public RightTriangle(int x, int y, int height, Color c) { 
    
    super(x,y,height,height, c);
    this.height = height;
    coloring = c;
  }  
  
  /** 
   * boolean method to determine whether the pointX and the pointY is inside of the RightTriangle
   * basically what i'm doing here is I used the property of gradient
   * I checked that if x is equals to a number, then yMax is suppose to be number that is the maximum for y if it's included in the RightTriangle
   * if the value of pointY is lesser or equals with the yMax then it is inside of the RightTriangle
   * and also check whether pointY is greater or equals than y. if it is lesser means it is not included
   * also for the x as the minimum of x and xrT is the maximum of x
   * @param pointX for checker point of x and pointY for checker point of y
   * @return true or false for isOn
   * */
  public boolean isOn(int pointX, int pointY) {
    
    xrT = x + height;
    yrT = y + height;
    int yMax;
    yMax = yrT+x-pointX;
    
    
    if(pointY <= yMax && pointY >= y  && pointX >= x && pointX <= xrT) {
      
     return true;
    }
    
    else {
      
      return false;
      
    }
  }
  
  /**
   * this method is for moving the left upper corner coordinate of the RightTriangle (adding) so original point+the adding
   * @param  deltaX is for the adding  x,  deltaY is for adding in y
   * */
  public void shiftBy(int deltaX, int deltaY) {
    
    x+= deltaX;
    y+= deltaY;
    
  }
  
  /**
   * this method is to move the left upper corner coordinate of the circle to a new point
   * @param  newX is the new coordinate of x newY is the new coordinate of y
   * */
  public void moveTo(int newX, int newY) {
    
    x = newX;
    y = newY;
    
  }
  
  /**
   * this method is to print out the string that is stored inside the variable text (coordinate of left upper corned and it's height)
   * @return text : the text stored in the variable
   * */
  
  public String toString(){
    if(coloring == null) {
      coloring = new java.awt.Color(0,0,0);
    }
    String text = "This Right Triangle coordinate of the left uppoer corner is (" + x + "," + y + ") Its height is " + height + " and it's color is " + coloring;
    
    return text;
  }
  /**
   * Display this ball on the given graphics context
   * @param g the graphics context where this ball should be drawn
   */  
  public void paintComponent(Graphics g) {
    //creating a polygon for right triangle
    Polygon rightTriangle = new Polygon( );
    g.setColor(coloring);
    
    //set up the point for the limit of each point of the triangle
    rightTriangle.addPoint( x, y );
    
    rightTriangle.addPoint( x+height, y );
    rightTriangle.addPoint( x, y+height );
    g.drawPolygon ( rightTriangle );
    if(testing == true) { 
      g.fillPolygon( rightTriangle );
    }
  }
  
  
  //create a method to set the testing to be false, which determine whether the fillOval will be filled or not
  //I assume that if the shape is not selected, then the shape will not be filled by the color.
  public void setTesting() {
    testing = false; 
  }
  
 /*
   * method for returning the value of x of the circle, which is the center.
   * @return x
   * */
  public int returnX() {
    return x; 
  }
    /*
   * method for returning the value of y of the circle, which is the center.
   * @return y
   * */
  public int returnY() {
    return y; 
  }
}