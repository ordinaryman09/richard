import java.awt.*;
import javax.swing.*;
import java.util.*;
/** 
 * @author Richard Lung
 * @version 1.0
 * */

//create a class for view.
public class GraphicsView extends JPanel implements viewInterface {
  // instance variables
  private DrawingBoard db;  // the SimModel we are viewing
  
  /**
   * Construct a new GraphicsView viewer for the given model
   * @param db  The model we are watching
   */
  public GraphicsView(DrawingBoard db) {
    this.db =db;
  }
  
  /**
   * React when notified of a change by a model by repainting this view
   */
  public void notifyViewer() {
    repaint();
  }
  
  /**
   * Repaint the simulation by requesting each item to repaint itself
   * @param g the graphics context where the painting should take place
   */
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    
    
    Rectangle bounds = getBounds();
    g.clearRect(0, 0, bounds.width, bounds.height);
    
    java.util.List things = db.returnList();
    Iterator it = things.iterator();
    while (it.hasNext()) {
      Shape thing = (Shape)it.next();
      thing.paintComponent(g);
    }
  }
  
}
