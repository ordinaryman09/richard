import java.awt.*;
/** 
 * @author Richard Lung
 * @version 1.0
 * */
//declaring class Circle for extending the AbstractShape
public class Circle extends AbstractShape{
  
  //declare the coordinate of the center for x and y and also r ( radius )
  private int centerX;
  private int centerY;
  private int r;
  
  /**
   * declare constructor Circle
   * @param  x for x coordinate,  y for y coordinate, r for radius,  c for color of the circle
   * */
  public Circle(int x, int y, int r, Color c) { 
    
    super(x-r,y-r,r*2,r*2, c);
    this.r = r;
    centerX = x;
    this.x = x;
    centerY = y;
    this.y = y;
    coloring = c;
    
  }  
  
  /**
   * method boolean to determine whether the pointX and pointY is inside the circle or outside the circle
   * this methodi is calculating the radius by using phytagoras theorm for the coordinate x and y inputted and compared with the radius set up in the constructor
   * if the new radius is bigger, then it means that the point is not inside the circle
   * @param  pointX for the coordinate of x and  pointY is for coordinate of y
   * */
  public boolean isOn(int pointX, int pointY) {
    //variable for storing the new radius
    int pointR;
    //this is the calculation of phytagoras theorm
    pointR = (int)(Math.sqrt((((pointX-centerX)*(pointX-centerX))+ ((pointY-centerY)*(pointY-centerY)))));
    
    if( pointR > r) {
      //System.out.println(x);
      //    System.out.println(y);
      return false;
      
    }
    
    else {
      //  System.out.println(x);
      // System.out.println(y);
      return true;
      
    }
    
    
    
    
  }
  
  
  /**
   * this method is for moving the center coordinate of the circle (adding) so original point+the adding
   * @param  deltaX is for the adding in x, deltaY is for adding in y
   * */
  public void shiftBy(int deltaX, int deltaY) {
    
    centerX+= deltaX;
    x += deltaX;
    centerY+= deltaY;
    y += deltaY;
    
  }
  
  /**
   * this method is to move the center coordinate of the circle to a new point
   * @param  newX is the new coordinate of x newY is the new coordinate of y
   * */
  public void moveTo(int newX, int newY) {
    
    centerX = newX;
    x = newX;
    centerY = newY;
    y = newY;
  }
  
  /**
   * this method is to print out the string that is stored inside the variable text (the location of center coordinate of circle and the radius)
   * @return text : the text stored in the variable
   * */
  public String toString(){
    if(coloring == null) {
      coloring = new java.awt.Color(0,0,0); 
    }
    String text = "This center of circle point is (" + centerX + "," + centerY + ") Its radius is " + r + " and it's Color is " + coloring;
    
    return text;
  }
  
  /**
   * Display this ball on the given graphics context
   * @param g the graphics context where this ball should be drawn
   */
  public void paintComponent(Graphics g) {
    
    //set the color
    g.setColor(coloring);
    //draw the oval
    g.drawOval(x-(r/2),y-(r/2),r,r);
    
    //this is the boolean variable that declared in the abstract shape and used to checked whether the selected shape is true or not
    //if it's true then filled the oval with the color.
    if(testing == true) {
      g.fillOval(x-(r/2),y-(r/2),r,r); 
    }
  }

  //create a method to set the testing to be false, which determine whether the fillOval will be filled or not
  //I assume that if the shape is not selected, then the shape will not be filled by the color.
  public void setTesting() {
    testing = false; 
  }
  
  /*
   * method for returning the value of x of the circle, which is the center.
   * @return x
   * */
  public int returnX() {
    return x; 
  }
    /*
   * method for returning the value of y of the circle, which is the center.
   * @return y
   * */
  public int returnY() {
    return y; 
  }
  
}