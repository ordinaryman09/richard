import java.util.*;
import java.awt.Color;
/** 
 * @author Richard Lung
 * @version 1.0
 * */
//declare class DrawingBoard
public class DrawingBoard{
  //declare the ArrayList for Shape
  private ArrayList<Shape> shape;
  //declare Shape for store the shapeselected
  private Shape shapeselected;
  
  private ArrayList<viewInterface> viewers;
  private boolean selectedStatus;   //for the selected status, true or not
  private boolean createStatus; //for the create shape status , true or not
  private Color colorSetter; // variable to set up the color 
  private static Random random; //a static variable to set up color randomly
  
  //create a constructor
  public DrawingBoard(){
    //declaring a new arraylist for shape
    shape = new ArrayList<Shape>();
    viewers = new ArrayList<viewInterface>();
    random = new Random( System.currentTimeMillis( ) );
  }
  
  
  /**
   * set up the coordinate of the selected shape
   * @param x for the x and y for the y
   * */
  public void setCoordinateSelected(int x, int y){
    
    int index = shape.size();
    
    boolean checker = false; 
    int i = index - 1;
    // check whether the point is on the shape, if it exist, select it and move it to the top most
    while (i >= 0 && checker == false) {
      if (shape.get(i).isOn(x,y) == true) {
        shapeselected = shape.get(i);
        shape.get(i).setSelected(true);
        shape.remove(shapeselected);
        shape.add(shapeselected);
        checker = true;
        i--;
      }
      else {
        shapeselected = null;
        i--;
      }
    }
  }
  
  //this is a checker for coorinates that will return boolean to determine whether it will be processed for the filled ( to prevent error if there's nothing clicked )
  public boolean checkCoor(int x, int y) {
    boolean tester = false;
    int i = shape.size() - 1;
    //from the top most shape, check whether the point is on the shape, if it exist, select it and move it to the top most
    while (i >= 0 && tester == false) {
      if (shape.get(i).isOn(x,y) == true) {
        tester = true;
        i--;
      }
      else 
        i--;     
    }
    return tester;
  }
  
  
  /**
   * method for adding the shape into the arraylist
   * setSelected to be true
   * @param newShape required Shape ( at this point, Circle, RightTriangle)
   * */
  public void addShape(Shape newShape){
    int  index = shape.size();
    
    if(index == 0 ) {
      
      shape.add(newShape);
      newShape.setSelected(true);
      shapeselected = newShape;
      
      
    }
    
    else {
      shape.get(index - 1).setSelected(false);
      shape.add(newShape);
      newShape.setSelected(true);
      shapeselected = newShape;
      
      
    }
    notifyListener();
  }
  //method to remove the shape selected and change the seleced shape into the previous shape stored in the array
  
  
  public void removeSelected(){
    if (shapeselected != null) {
      if (shape.size() > 1) {
        shape.remove(shapeselected);
        shapeselected = shape.get(shape.size() - 1);
      }
      else if (shape.size() == 1) {
        shape.remove(shapeselected);
        shapeselected = null;
      }
      else if (shape.size() == 0) {
        shapeselected = null;
      }   
    }
  }
  
  /**
   * method to determine which shape is currently selected
   * @return shapeselected is the shape that is currently selected
   * */
  public Shape getSelected(){
    return shapeselected;
  }
  
  
  //  set color for the selected shape
   
   
  public void setColorSelected(){
    int index = shape.size();
    colorSetter = new Color(random.nextInt(256),random.nextInt(256),random.nextInt(256));
    if( shapeselected != null ) {
      shape.get(index - 1).setColor(colorSetter);
      shapeselected = shape.get(index - 1);
      
    }
    else{
      //throwing exception if there's no shape selected
      throw new IllegalArgumentException( "No shape is selected." );
    }
  }
  
  /** 
   * move the selected shape.
   * @param changeInX for adding the x , and changeInY for adding the y
   * */
  public void moveSelected(int changeInX, int changeInY){
    
    int index = shape.size();
    
    if( shapeselected != null ) {
      shape.get(index - 1).shiftBy( changeInX, changeInY);
      shapeselected = shape.get(index - 1);
      
    }
    else{
      //throwing exception if there's no shape selected
      throw new IllegalArgumentException( "No shape selected." );
    }
  }
  
  //method to get the size of the shape
  public int getSize() {
    
    return shape.size();
    
  }
  
  //method for storing the Shape in iterator and print out the shape in the list
  public void shapeList(){
    
    Iterator<Shape> i = shape.iterator();
    
    while( i.hasNext() ) {
      System.out.println( i.next() + "\n" );
    }
  }
  
  /**
   * create a method addView to add the viewInterface
   * @param v viewInterface
   * */
  public void addView(viewInterface v) {
    
    viewers.add(v);
    
  }
  
  /**
   * set the status of the shape
   * @param b false or not for the selected
   * */
  public void setStatus(boolean b) {
    
    selectedStatus = b;
    
  }
  
  /**
   * return the status of the shape selected, whether it is false or not
   * @return selectedStatus
   * */
  public boolean returnStatus() {
    return selectedStatus; 
  }
  
  /**
   * return the status whether currently create the status or not.
   * @param b
   * */
  public void setcreateStatus(boolean b) {
    createStatus = b;
    
  }
  
  /**
   * returns the value of the create status, whether it is currently creating the status or not
   * @return createStatus
   * */
  public boolean createStatus() {
    return createStatus;
  }
  
  /**
   * addListener method
   * @param c viewInterface
   * */
  public void addListener( viewInterface c ) {
    if ( c != null ) {
      viewers.add( c );
      c. notifyViewer();
    }
  }
  
  //method to notifyListener the updates
  public void notifyListener() {
    Iterator<viewInterface> it = viewers.iterator();
    while (it.hasNext()) {
      viewInterface vI = it.next();
      vI.notifyViewer();
      
    } 
  }
  
 
  
  /**
   * 
   * return the value of the colo
   * @return colorSetter
   * */
  public Color returnColor() {
    return colorSetter; 
  }
  
  /**
   * return list method
   * @return new ArrayList<Shape>(shape)
   * */
  public List returnList() {
    
    return new ArrayList<Shape>(shape);
    
  }
  
}
