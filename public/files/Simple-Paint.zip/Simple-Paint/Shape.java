import java.awt.*;
/** 
 * @author Richard Lung
 * @version 1.0
 * */
//declare an interface class
public interface Shape {
  
  public int x = 0;
  public int y = 0;
  
  //declaring some methods to be implemented
  boolean isOn(int pointX, int pointY); 
 
  //declare isSelected to check whether the shape is selected or not
  boolean isSelected();
  
  //setSelected method that require boolean method from the user to set the shape selected to be true or not
  void setSelected(boolean b);
  
  //set up the color of the shape
  void setColor(Color c);
  //method to get the color from the user
  Color getColor();
  
  //method shiftBy to shift the shape by parameter deltaX and deltaY
  void shiftBy(int deltaX, int deltaY);
  
  //move the shape to a new destination, newX and newY
  void moveTo(int newX, int newY);
    
  //create a paintComponent method for paint the shape into the window
  public void paintComponent(Graphics g);
 
  //create a method setTesting to set the testing to be false later on. this is done for the purpose of the button, if one of the button clicked.
  public void setTesting();
  
  //create a method returnX to return the x coordinate to be used for dragging
  public int returnX();
  
  //create a method returnY to return the y coordinate to be used for dragging
  public int returnY();

}