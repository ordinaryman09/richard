import java.awt.*;

/** 
 * @author Richard Lung
 * @version 1.0
 * */

//create a viewInterface that contains notifyViewer method to notify the changed.
public interface viewInterface {
  
  //create a notifyViewer method to notify the changed.
  public void notifyViewer();
  
  
}
