import java.awt.*;
import javax.swing.*;

/** 
 * @author Richard Lung
 * @version 1.0
 * */

public class GraphicsEditorApp {
  
 
  /** 
   * Create window, viewer, and model and run simulation
   */
  public static void main(String[] args) {
    // Create the simulation model and populate it
    DrawingBoard db = new DrawingBoard();
    
     //Create a graphics view,  put it in a window, and show it
    JFrame frame = new JFrame("DrawingBoard");
  frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    GraphicsNewControl controller = new GraphicsNewControl( db );
    frame.getContentPane().add( controller);
    viewText disp = new viewText( db ); 
     db.notifyListener();
    frame.getContentPane().add( disp,BorderLayout.NORTH );
    frame.pack( );
    frame.setVisible( true );
   
  }
}
