import java.awt.*;
/** 
 * @author Richard Lung
 * @version 1.0
 * */
//create an abstract class to implements the interface Shape
public abstract class AbstractShape implements Shape {
  //declaring variables for common shapes required
  int x;
  int y;
  int height;
  int width;
  int pointX;
  int pointY;
  Color coloring;
  boolean testing;
  
  /** 
   * declare a constructor with parameter
   * @param x for the location of coordinate x, y for the location of coordinate y, height is for the height of the shape,  width is for the width of the shape, c is to set up the color of the shape
   * */
  public AbstractShape(int x, int y, int height, int width, Color c) {
    this.x = x;
    this.y = y;
    this.height = height;
    this.width = width;
    coloring = c;
  }
  
//abstract method to be override in class circle and right triangle
  public abstract void shiftBy(int deltaX, int deltaY);
  
//abstract method to be override in class circle and right triangle
  public abstract void moveTo(int newX, int newY);
  
  /**
   * setColor for the shape
   * @param c (required type Color)
   * */
  public void setColor(Color c) {
    
    //set the coloring to store Color c
    coloring = c;
    
  }
  
  
  /** method for return the value of coloring
    *   @return coloring - the color stored in the variable
    * */

  
  public Color getColor() {
    
    return coloring;
    
  }
  
//abstract method to be override in class circle and right triangle
  public abstract boolean isOn(int pointX, int pointY); 
  
  /** method to setSelected for the shape ( required boolean true or false )
    @param b (true or false)
    **/
  public void setSelected(boolean b) {
    
    testing = b;
    
  }
  
  /** method to determine whether the shape is currently selected or not
    * 
    * @return testing ( the value of boolean stored by testing )
    * */
  
  
  public boolean isSelected() {
    
    return testing;
    
  }
  
}