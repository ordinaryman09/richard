import java.io.*;
import javax.swing.*;

/**
 * @author Richard Lung
 * @version 1.0
 * */

//instantiate a class
public class QueryTree {
  //instantiate tree to mantain the growth of the Tree and first as the the one that's pointer to the first question.
  private Tree tree;
  private Tree first;
  
  //instantiate the first and the tree. computer that's for initialize the tree, if the user choose to construct a new tree
  public QueryTree()  {
    first = new Tree("computer", null,null);
    tree = first;
  }
  
  /**
    * create a boolean method to determine whether there's another question or not.
    * returns true if there is another question to ask. A question is different from the final guess.
    * @return checker this is true or false
    * */
  public boolean hasNextQuestion() {
    boolean checker = false;   
    if(tree.left == null) {
      checker = false; 
    }
    else { checker = true; }
    return checker;   
  }
  
  /**
   * a method that returns the next question to ask the user. 
   * @return tree.item this is the next question
   * @throws IllegalStateException
   * 
   * */
  public String nextQuestion() { 
    if ( hasNextQuestion() == true) {
      return tree.item ;}
    else { throw new IllegalStateException(); }
  }
  
  /**
   * a method to moves to the next question in this QueryTree based on the user response to the previous question: 'y' or 'n'. Should not be case sensitive.
   * @param input this suppose to be y or n 
   * @throws IllegalArgumentException
   * */
  public void userResponse(char input) {
    if( input == 'y' || input == 'Y' ) {
      tree = tree.right;
    }
    else if ( input == 'n' || input == 'N' ) {
      tree = tree.left;
    } 
    else {
      throw new IllegalArgumentException();  
    }
  }
  
  /**
   * a method to return the guess of this QueryTree.
   * @return tree.item this is the final guess
   * */
  public String finalGuess() { 
    
    return tree.item ; }
  
  /**
   * Update this QueryTree using the given data: 
   * @param q is the new question
   * @param item is the new item that is being added to the QueryTree
   * @param input is the yes or no answer that leads from this question to the new item.
   * @throws IllegalArgumentException
   * */
  public void updateTree(String q, String item, char input) {
    
    Tree holder = new Tree(tree.item, null,null);
    
    if(input == 'y' || input == 'Y') {
      if(first == tree) { 
        tree.item = q;
        first = tree;
      }
      else { 
        tree.item = q;
      }
      tree.right = new Tree(item,null,null);
      tree.left = holder;
    }
    else if( input == 'n' || input == 'N' ) {
      if(first == tree) { 
        tree.item = q;
        first = tree;
      }
      else { 
        tree.item = q;
      }
      tree.left = new Tree(item,null,null);
      tree.right = holder;   
    }
    //if the user input is not y / Y / n / N
    else { throw new IllegalArgumentException(); }
  }
  
  /**
   * readIn a new set of questions/items into this QueryTree from the given file, replacing whatever was currently in the QueryTree
   * @param f this is the parameter that will get the name of the file
   * @throws IllegalArgumentException
   * */
  public void readIn(File f) {
    try { 
    BufferedReader input = new BufferedReader(new FileReader(f));
    first = readFile(input);
    tree = first;    
    input.close(); }
    catch( IOException e ) { throw new IllegalArgumentException(); }
  }
  
  /** create a private method for recursively reading the file.
    * @param input this is for passing the line
    * @throw IllegalArgumentException
    * */
  private Tree readFile(BufferedReader input) {
    try { char charHolder = input.readLine().charAt(0);   
    Tree holder;
    //the base case if the node is an answer node;
    if( charHolder == 'A' ) {
      return new Tree( input.readLine(), null,null );     
    }    
    else  {           
      holder = new Tree(input.readLine(), null,null);      
      holder.left  = readFile(input);
      holder.right = readFile(input);     
      return holder;
    }
    }
    catch (IOException e ) { throw new IllegalArgumentException(); }
  }
  
  /**
   * writeOut the current set of questions/items in this QueryTree out to the given file. Does not change the current state.
   * @param f this parameter will get the file name that will be saved to.
   * @throws IllegalArgumentException
   * */
  public void writeOut(File f)  {
    try {
    PrintWriter output = new PrintWriter(new BufferedWriter(new FileWriter(f)));
    Tree holder = first;
    writePrinter(output, holder); 
    output.close();
    }
    catch(IOException e ) { throw new IllegalArgumentException(); }
  }
  
  /**
   * create a private method for recursively writing the existing tree into the file.
   * @param output the line for output
   * @param holder the Tree
   * */
  private void writePrinter(PrintWriter output, Tree holder) {
    //base case if it's answer node
    if( holder.left == null ) {
      output.println("A:");
      output.println(holder.item);
      return;
    }
    else {
      output.println("Q:");
      output.println(holder.item);
      writePrinter(output,holder.left);
      writePrinter(output,holder.right);
    }
  }
  
  //create a private class Tree as a Node.
  private class Tree {
    
    Tree right;
    Tree left;
    String item;
    Tree( String item, Tree left, Tree right  ) {
      
      this.item = item;
    }
  } 
}