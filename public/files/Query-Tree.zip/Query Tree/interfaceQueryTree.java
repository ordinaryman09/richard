import javax.swing.*;
import java.io.*;

/**
 * @author Richard Lung
 * @version 1.0
 * */

//create a class as an interface for the QueryTree
public class interfaceQueryTree {
  //creating a QueryTree instance
  private static QueryTree qt;
  
  /**
   * create a private static method to keep continues asking the question to the user if it still has next question
   * @throws IOException
   * */
  private static void existingFile() throws IOException {
    //keep continue asking if there's still next question
    while(qt.hasNextQuestion() == true) {
      String st = JOptionPane.showInputDialog(qt.nextQuestion()); 
      char checker = st.charAt(0);
      qt.userResponse(checker);
    }
    //after it doesn't have any next question, which mean already in the leaf node, return the final guess
    //prompt for asking the user whether it's the right answer or not
    String st = JOptionPane.showInputDialog("is your answer is : " + qt.finalGuess() + "\n answer with y/n in the provided box");
    char checker = st.charAt(0);
    //check if the user response is n / N means the guess is not right, update the Tree
    if(checker == 'n' || checker == 'N') {
      String q = JOptionPane.showInputDialog("what is the question to distinguish that?");
      String item = JOptionPane.showInputDialog("what is the item that you're thinking of?");
      String response = JOptionPane.showInputDialog("what is the response that distinguish from that answer? MUST BE y/n");
      char charResponse = response.charAt(0);
      if(charResponse != 'n' && charResponse != 'N' && charResponse != 'y' && charResponse != 'Y') {
        JOptionPane.showMessageDialog(null, "you put invalid char, automatically consider response that distinguish your answer is y"); 
        charResponse = 'y';
      }
      //pass in the value , update the tree
      qt.updateTree(q,item,charResponse);  
      //qt.saveFile();
      String save = JOptionPane.showInputDialog("do u want to save the file?");
      char saveFile = save.charAt(0);
      //save file if the user want to save file
      if(saveFile == 'y' || saveFile == 'Y') {
        saveFile();
      }    
      //do nothing, the user do not want to save the file
      else if ( saveFile == 'n' || saveFile == 'N') {     
      }
      //do nothing since the user put invalid char, assume that the user do not want to save it
      else { JOptionPane.showMessageDialog(null, "you put invalid char, automatically consider you don't wanna save it");    
      }  
    }
    //if the user answer yes, means our guess is true
    else if ( checker == 'y' || checker == 'Y' ) { }
    //assume that our guess is right
    else { JOptionPane.showMessageDialog(null, "you put invalid char, automatically consider that our guess is your answer");  }
    //ask the user whether the user want to play again or not
    playAgain();
  }
  /**
   * create a private method for saving the file if the user wants to save the file
   * @throws IOException
   * */
  private static void saveFile() throws IOException {
    
    File f = new File("write.txt");
    qt.writeOut(f);
    
  }
  /** 
   * create a private method for opening the file if the user decided to open the existing file
   * @throws IOException
   * */
  private static void openFile() throws IOException {
    
    File f = new File("write.txt");
    qt.readIn(f);
    
    
  }
  
  /**
   * create a method that asking the user whether the user wants to play again or not and handle if the user wants to play again.
   * @throws IOException
   * */
  private static void playAgain() throws IOException {
    
    String exit = JOptionPane.showInputDialog("do u want to play again?");
    char exitChar = exit.charAt(0);
    //if the user do not want to play again
    if( exitChar == 'n' || exitChar == 'N' ) {
      JOptionPane.showMessageDialog(null, "Thanks for using this program, it's fun right?");
      return;
    }
    //if the user want to play the game again.
    else if ( exitChar == 'y' || exitChar == 'Y') { 
      qt = new QueryTree();
      fileStarter();
    }
    else { 
      //if the user put invalid char, assume that the user do not want to play again
      JOptionPane.showMessageDialog(null, "you put invalid char, this program consider that you don't want to play again");
      JOptionPane.showMessageDialog(null, "Thanks for using this program, it's fun right?");
      return;
    }
  }
  /**
   * this is a method that can be the starter or to continues after the user is done playing, asking whether the user wants to create another file or not
   * @throws IOException
   * */
  private static void fileStarter() throws IOException {
    String s = JOptionPane.showInputDialog( "Do you want to create a new file?" );
    char checker = s.charAt(0);
    //if the user wants to open the existing file
    if(checker == 'n' || checker == 'N') {
      qt = new QueryTree();
      
      openFile();
      existingFile();
    }
    //if the user want to create a new file
    else if ( checker == 'y' || checker == 'Y' ) {
      qt = new QueryTree();
      existingFile();
    }
    else {
      //consider that the user wants to create a new file since the user put invalid char
      JOptionPane.showMessageDialog(null, "you put invalid char, this program consider that you want to create a new file");
      qt = new QueryTree();
      existingFile();
    }
  }
  /**
   * main method, call the fileStarter method to begins the game
   * @throws IOException
   * */
  public static void main(String args[]) throws IOException {
    fileStarter();
  }
}