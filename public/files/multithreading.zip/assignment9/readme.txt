I ran into issues when my perfomance did not give significant difference. It was actually because
I did not use the multithreading effectively in my code. 
Another issue is in my laptop which only have 2 cores, it seems that the multithreading does not really
impact the perfomance significantly if we specify the number of threads more than 2.

I think the new impelementation of SRT will impact the perfomance significantly in the
computers that have many cores like for example in seasnet machine.
when I tried to execute the code in the seasnet machine, the perfomance increase exponentially
as the # of thread we specify increase

However, I also think that there's a limit where the increase in # of threads we specify does not 
affect significantly anymore to the perfomance due to limitation of the hardware.
